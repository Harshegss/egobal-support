<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard-E-Global Support</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

 <?php include("header-links.php"); ?>


</head>

<body>

<?php include("header.php"); ?>

 <?php include("side-bar.php"); ?>

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Models</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item ">Services</li>
          <li class="breadcrumb-item active">Models</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <section class="section">
      <div class="row">
        <div class="col-12 mt-5">
            <div class="card pt-4">
                <div class="category-add-content">
                    <h4 class="card-title"> Models</h4>
                    <a href="add-models.php" class="btn d-button py-2 px-4" >Add Model </a>
                </div>
                <div class="card-body table-scroll">
            <!-- Table with stripped rows -->
                  <table class="table datatable table-text-center ">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Models</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th scope="row">1</th>
                        <td>Latitude15 5520</td>
                          <td class="">
                              <ul class="d-flex list-unstyled action_btn">
                                  <li class="mx-2">
                                      <form action="submission-detail.php" method="post">
                                  <button type="button">
                                      <img src="assets/img/edit.png" >
                                      </button>
                              </form></li>
                              <li><form action="##" method="post">
                                  <button type="button">
                                      <img src="assets/img/trash.png" >
                                      </button>
                              </form></li>
                              </ul>
                          </td>
                      </tr>
                      <tr>
                        <th scope="row">2</th>
                        <td>Latitude 5531</td>
                          <td class="">
                              <ul class="d-flex list-unstyled action_btn">
                                  <li class="mx-2">
                                      <form action="submission-detail.php" method="post">
                                  <button type="button">
                                      <img src="assets/img/edit.png" >
                                      </button>
                              </form></li>
                              <li><form action="##" method="post">
                                  <button type="button">
                                      <img src="assets/img/trash.png" >
                                      </button>
                              </form></li>
                              </ul>
                          </td>
                      </tr>
                      <tr>
                        <th scope="row">3</th>
                        <td>Latitude 7320 2-in-1</td>
                          <td class="">
                              <ul class="d-flex list-unstyled action_btn">
                                  <li class="mx-2">
                                      <form action="submission-detail.php" method="post">
                                  <button type="button">
                                      <img src="assets/img/edit.png" >
                                      </button>
                              </form></li>
                              <li><form action="##" method="post">
                                  <button type="button">
                                      <img src="assets/img/trash.png" >
                                      </button>
                              </form></li>
                              </ul>
                          </td>
                      </tr>
                      <tr>
                        <th scope="row">4</th>
                        <td>Latitude 13 7320</td>
                          <td class="">
                              <ul class="d-flex list-unstyled action_btn">
                                  <li class="mx-2">
                                      <form action="submission-detail.php" method="post">
                                  <button type="button">
                                      <img src="assets/img/edit.png" >
                                      </button>
                              </form></li>
                              <li><form action="##" method="post">
                                  <button type="button">
                                      <img src="assets/img/trash.png" >
                                      </button>
                              </form></li>
                              </ul>
                          </td>
                      </tr>
                    
                     
                      
                    </tbody>
                  </table>
                  <!-- End Table with stripped rows -->           
        </div>
        </div>
        </div>
        
      </div>
    </section>

  </main><!-- End #main -->


     <?php include("footer.php"); ?>


</body>

</html>