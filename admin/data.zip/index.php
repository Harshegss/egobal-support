<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard-E-Global Support</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
<?php include("header-links.php"); ?>
</head>

<body>
    
<?php include("header.php"); ?>

<?php include("side-bar.php"); ?>
 

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
        
         <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Home Banner</h5>
                  <form action="" method="">
                  <div class="row">
                     <div class="col-lg-7">
                         <div class="banner-text">
                             <div class="form-field">
                                 <label>Banner Heading</label>
                                 <input type="text" class="form-control" placeholder="Banner heading" name="" value="">
                             </div>
                              <div class="form-filed mt-3">
                                  <label>Choose Banner Image</label>
                             <input type="file" class="form-control">
                             </div>
                             
                         </div>
                         <button class="btn d-button mt-3" type="submit">Submit</button>
                     </div>
                     <div class="col-lg-5">
                         <div class="banner-image">
                             <img src="https://thetestingserver.com/egssservices/assets/images/banner.jpg" class="img-fluid">
                         </div>
                         
                     </div>
                  </div>
                 </form>
                </div>
              </div>
        </div>
      </div>
        
        
      <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                 <div class="d-flex justify-content-between">
                      <h5 class="card-title">Feature Banner</h5>
                      <button class="btn d-button mt-4" data-bs-toggle="modal" data-bs-target="#exampleModal">Add New Slider</button>
                 </div>
                 
                  <div class="row">
                     <div class="col-lg-4">
                          <form action="" method="">
                        <div class="feature-banner">
                            <div class="banner-text">
                               <div class="banner-image">
                                    <label>Choose Image</label>
                                   <img src="https://thetestingserver.com/egssservices/assets/images/slider/slider.png" class="img-fluid">
                                </div>
                             <div class="form-filed mt-3">
                               <input type="file" class="form-control">
                             </div>
                                <div class="form-field">
                                 <label>Banner Heading</label>
                                 <input type="text" class="form-control" placeholder="Banner heading" name="" value="">
                             </div>
                              <div class="form-field mt-1">
                                 <label>Banner Subheading</label>
                                 <input type="text" class="form-control" placeholder="Banner subheading" name="" value="">
                             </div>
                              <div class="form-field mt-1">
                                 <label>Shop Button Link</label>
                                 <input type="url" class="form-control" placeholder="url"  name="" value="">
                             </div>
                             <button class="btn d-button mt-4" type="submit">Submit</button>
                                
                         </div>
                        </div>
                         </form>
                     </div>
                    <div class="col-lg-4">
                         <form action="" method="">
                        <div class="feature-banner">
                         <div class="banner-text">
                             
                                      <div class="banner-image">
                                           <label>Choose Image</label>
                                    <img src="https://thetestingserver.com/egssservices/assets/images/slider/slider.png" class="img-fluid">
                                 </div>
                             <div class="form-filed mt-3">
                               <input type="file" class="form-control">
                             </div>
                                <div class="form-field">
                                 <label>Banner Heading</label>
                                 <input type="text" class="form-control" placeholder="Banner heading" name="" value="">
                             </div>
                              <div class="form-field mt-1">
                                 <label>Banner Subheading</label>
                                 <input type="text" class="form-control" placeholder="Banner subheading" name="" value="">
                             </div>
                              <div class="form-field mt-1">
                                 <label>Shop Button Link</label>
                                 <input type="url" class="form-control" placeholder="url"  name="" value="">
                             </div>
                             <button class="btn d-button mt-4" type="submit">Submit</button>
                                
                         </div>
                        </div>
                         </form>
                     </div>
                  </div>
                
                </div>
              </div>
        </div>
      </div>
     
        <div class="row mt-5">
          <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Home Feature</h5>
                  <form action="" method="">
                  <div class="row">
                     <div class="col-lg-7">
                         <div class="banner-text">
                             <div class="form-field">
                                 <label>Feature Heading</label>
                                 <input type="text" class="form-control" placeholder="Banner heading" name="" value="">
                             </div>
                             <div class="form-field mt-2">
                                 <label>Feature Description</label>
                                <textarea class="tinymce-editor">
                                    <p>Hello World!</p>
                                 </textarea>
                             </div>
                         </div>
                         <button class="btn d-button mt-3" type="submit">Submit</button>
                     </div>
                     <div class="col-lg-5">
                         <label>Feature Image</label>
                         <div class="banner-image mt-4">
                             <img src="https://thetestingserver.com/egssservices/assets/images/newbieguide.png" class="img-fluid w-50">
                         </div>
                         <div class="form-filed mt-3">
                             <input type="file" class="form-control">
                         </div>
                           <div class="form-field mt-4">
                                 <label>Explore Button Link</label>
                                 <input type="url" class="form-control" placeholder="url"  name="" value="">
                             </div>
                     </div>
                  </div>
                 </form>
                </div>
              </div>
        </div>
      </div>
        <div class="row mt-5">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Home Feature</h5>
                  <form action="" method="">
                  <div class="row">
                     <div class="col-lg-7">
                         <div class="banner-text">
                             <div class="form-field">
                                 <label>Feature Heading</label>
                                 <input type="text" class="form-control" placeholder="Banner heading" name="" value="">
                             </div>
                             <div class="form-field mt-2">
                                 <label>Feature Description</label>
                                <textarea class="tinymce-editor">
                                    <p>Hello World!</p>
                                 </textarea>
                             </div>
                         </div>
                         <button class="btn d-button mt-3" type="submit">Submit</button>
                     </div>
                     <div class="col-lg-5">
                         <label>Feature Image</label>
                         <div class="banner-image mt-4">
                             <img src="https://thetestingserver.com/egssservices/assets/images/topapps.png" class="img-fluid w-50">
                         </div>
                         <div class="form-filed mt-3">
                             <input type="file" class="form-control">
                         </div>
                           <div class="form-field mt-4">
                                 <label>Explore Button Link</label>
                                 <input type="url" class="form-control" placeholder="url"  name="" value="">
                             </div>
                     </div>
                  </div>
                 </form>
                </div>
              </div>
        </div>
      </div>
        <div class="row mt-5">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Home Feature</h5>
                  <form action="" method="">
                  <div class="row">
                     <div class="col-lg-7">
                         <div class="banner-text">
                             <div class="form-field">
                                 <label>Feature Heading</label>
                                 <input type="text" class="form-control" placeholder="Banner heading" name="" value="">
                             </div>
                             <div class="form-field mt-2">
                                 <label>Feature Description</label>
                                <textarea class="tinymce-editor">
                                    <p>Hello World!</p>
                                 </textarea>
                             </div>
                         </div>
                         <button class="btn d-button mt-3" type="submit">Submit</button>
                     </div>
                     <div class="col-lg-5">
                         <label>Feature Image</label>
                         <div class="banner-image mt-4">
                             <img src="https://thetestingserver.com/egssservices/assets/images/popularizes-region-4c.png" class="img-fluid w-50">
                         </div>
                         <div class="form-filed mt-3">
                             <input type="file" class="form-control">
                         </div>
                         <div class="form-field mt-4">
                                 <label>Explore Button Link</label>
                                 <input type="url" class="form-control" placeholder="url"  name="" value="">
                             </div>
                     </div>
                  </div>
                 </form>
                </div>
              </div>
        </div>
      </div>
      
      
      <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                 <div class="d-flex justify-content-between">
                      <h5 class="card-title">Contact Boxes</h5>
              
                 </div>
                 
                  <div class="row">
                     <div class="col-lg-6">
                          <form action="" method="">
                        <div class="feature-banner">
                         <div class="banner-text">
                             
                                      <div class="banner-image">
                                           <label>Choose Image</label><br>
                                    <img src="https://thetestingserver.com/egssservices/assets/images/contact-forum-banner-v2.png" width="50%" class="img-fluid">
                                 </div>
                             <div class="form-filed mt-3">
                               <input type="file" class="form-control">
                             </div>
                                <div class="form-field">
                                 <label>Heading</label>
                                 <input type="text" class="form-control" placeholder="heading" name="" value="">
                             </div>
                              <div class="form-field mt-1">
                                 <label>Sub heading</label>
                                  <textarea class="tinymce-editor">
                                    <p>Hello World!</p>
                                 </textarea>
                             </div>
                              <div class="form-field mt-1">
                                 <label>Button Link</label>
                                 <input type="url" class="form-control" placeholder="url"  name="" value="">
                             </div>
                             <button class="btn d-button mt-4" type="submit">Submit</button>
                             
                                
                         </div>
                         
                        </div>
                        </form>
                     </div>
                    <div class="col-lg-6">
                         <form action="" method="">
                        <div class="feature-banner">
                         <div class="banner-text">
                             
                                      <div class="banner-image">
                                           <label>Choose Image</label><br>
                                    <img src="https://thetestingserver.com/egssservices/assets/images/contact-us-banner.png" width="50%" class="img-fluid">
                                 </div>
                             <div class="form-filed mt-3">
                               <input type="file" class="form-control">
                             </div>
                                <div class="form-field">
                                 <label> Heading</label>
                                 <input type="text" class="form-control" placeholder="heading" name="" value="">
                             </div>
                              <div class="form-field mt-1">
                                 <label>Sub heading</label>
                                  <textarea class="tinymce-editor">
                                    <p>Hello World!</p>
                                 </textarea>
                             </div>
                              <div class="form-field mt-1">
                                 <label>Button Link</label>
                                 <input type="url" class="form-control" placeholder="url"  name="" value="">
                             </div>
                             <button class="btn d-button mt-4" type="submit">Submit</button>
                             
                                
                         </div>
                         
                        </div>
                        </form>
                     </div>
                  </div>
                 
                </div>
              </div>
        </div>
      </div>
     
      
      
      <div class="row mt-5">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                  <h5 class="card-title">We Fix Your Devices</h5>
                
                  <div class="row" style="border-bottom:1px grey solid;padding-bottom:10px;">
                     <div class="col-lg-4 mt-1">
                           <form action="" method="">
                         <div class="banner-text p-5">
                             <img src="https://thetestingserver.com/egssservices/assets/images/icon/1.svg" class="img-fluid">
                             <div class="form-field mt-3">
                                 <label>Choose Icon</label>
                                 <input type="file" class="form-control" placeholder="Choose file" name="" value="">
                             </div>
                             <div class="form-field mt-2">
                                 <label>Heading</label>
                                 <input type="text" class="form-control" placeholder="Features heading" name="" value="">
                             </div>
                              <div class="form-field mt-3">
                             <button class="btn d-button" type="submit">Submit</button>
                             </div>
                         </div>
                           </form>
                     </div>
                     
                      <div class="col-lg-4 mt-1">
                           <form action="" method="">
                         <div class="banner-text p-5">
                             <img src="https://thetestingserver.com/egssservices/assets/images/icon/2.svg" class="img-fluid">
                              <div class="form-field mt-3">
                                 <label>Choose Icon</label>
                                 <input type="file" class="form-control" placeholder="Choose file" name="" value="">
                             </div>
                             <div class="form-field mt-2">
                                 <label>Heading</label>
                                 <input type="text" class="form-control" placeholder="Features heading" name="" value="">
                             </div>
                             <div class="form-field mt-3">
                             <button class="btn d-button" type="submit">Submit</button>
                             </div>
                         </div>
                          </form>
                     </div>
                     
                      <div class="col-lg-4 mt-1">
                           <form action="" method="">
                         <div class="banner-text p-5">
                             <img src="https://thetestingserver.com/egssservices/assets/images/icon/3.svg" class="img-fluid">
                              <div class="form-field mt-3">
                                 <label>Choose Icon</label>
                                 <input type="file" class="form-control" placeholder="Choose file" name="" value="">
                             </div>
                             <div class="form-field mt-2">
                                 <label>Heading</label>
                                 <input type="text" class="form-control" placeholder="Features heading" name="" value="">
                             </div>
                             <div class="form-field mt-3">
                             <button class="btn d-button" type="submit">Submit</button>
                             </div>
                         </div>
                          </form>
                     </div>
                     </div>
                       <div class="row">
                       <div class="col-lg-4 mt-1">
                            <form action="" method="">
                         <div class="banner-text p-5">
                             <img src="https://thetestingserver.com/egssservices/assets/images/icon/4.svg" class="img-fluid">
                              <div class="form-field mt-3">
                                 <label>Choose Icon</label>
                                 <input type="file" class="form-control" placeholder="Choose file" name="" value="">
                             </div>
                             <div class="form-field mt-2">
                                 <label>Heading</label>
                                 <input type="text" class="form-control" placeholder="Features heading" name="" value="">
                            
                             </div>
                              
                         <div class="form-field mt-3">
                             <button class="btn d-button" type="submit">Submit</button>
                             </div>
                         </div>
                          </form>
                     </div>
                      <div class="col-lg-4 mt-1">
                             <form action="" method="">
                         <div class="banner-text p-5">
                             <img src="https://thetestingserver.com/egssservices/assets/images/icon/5.svg" class="img-fluid">
                              <div class="form-field mt-3">
                                 <label>Choose Icon</label>
                                 <input type="file" class="form-control" placeholder="Choose file" name="" value="">
                             </div>
                             <div class="form-field mt-2">
                                 <label>Heading</label>
                                 <input type="text" class="form-control" placeholder="Features heading" name="" value="">
                            
                             </div>
                               
                         <div class="form-field mt-3">
                             <button class="btn d-button" type="submit">Submit</button>
                             </div>
                         </div>
                          </form>
                     </div>
                       <div class="col-lg-4 mt-1">
                             <form action="" method="">
                         <div class="banner-text p-5">
                             <img src="https://thetestingserver.com/egssservices/assets/images/icon/6.svg" class="img-fluid">
                              <div class="form-field mt-3">
                                 <label>Choose Icon</label>
                                 <input type="file" class="form-control" placeholder="Choose file" name="" value="">
                             </div>
                             <div class="form-field mt-2">
                                 <label>Heading</label>
                                 <input type="text" class="form-control" placeholder="Features heading" name="" value="">
                            
                             </div>
                               
                         <div class="form-field mt-3">
                             <button class="btn d-button" type="submit">Submit</button>
                             </div>
                         </div>
                          </form>
                     </div>
                  </div>
               
                </div>
              </div>
        </div>
      </div>
      
      
      <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                   <div class="row">
                     <div class="col-lg-4">
                          <form action="" method="">
                        <div class="feature-banner">
                         <div class="banner-text">
                             
                                      <div class="banner-image">
                                           <label>Choose Image</label><br>
                                    <img src="https://thetestingserver.com/egssservices/assets/images/smart%20diagnosis.png" width="50%" class="img-fluid">
                                 </div>
                             <div class="form-filed mt-3">
                               <input type="file" class="form-control">
                             </div>
                                <div class="form-field">
                                 <label>Heading</label>
                                 <input type="text" class="form-control" placeholder="heading" name="" value="">
                             </div>
                              <div class="form-field mt-1">
                                 <label>Description</label>
                                  <textarea class="tinymce-editor">
                                    <p>Hello World!</p>
                                 </textarea>
                             </div>
                              <div class="form-field mt-1">
                                 <label>Button Link</label>
                                 <input type="url" class="form-control" placeholder="url"  name="" value="">
                             </div>
                             <button class="btn d-button mt-4" type="submit">Submit</button>
                             
                                
                         </div>
                         
                        </div>
                        </form>
                     </div>
                    <div class="col-lg-4">
                         <form action="" method="">
                        <div class="feature-banner">
                         <div class="banner-text">
                             
                                      <div class="banner-image">
                                           <label>Choose Image</label><br>
                                    <img src="https://thetestingserver.com/egssservices/assets/images/warranty-policy.png" width="50%" class="img-fluid">
                                 </div>
                             <div class="form-filed mt-3">
                               <input type="file" class="form-control">
                             </div>
                                <div class="form-field">
                                 <label> Heading</label>
                                 <input type="text" class="form-control" placeholder="heading" name="" value="">
                             </div>
                              <div class="form-field mt-1">
                                 <label>Description</label>
                                  <textarea class="tinymce-editor">
                                    <p>Hello World!</p>
                                 </textarea>
                             </div>
                              <div class="form-field mt-1">
                                 <label>Button Link</label>
                                 <input type="url" class="form-control" placeholder="url"  name="" value="">
                             </div>
                             <button class="btn d-button mt-4" type="submit">Submit</button>
                             
                                
                         </div>
                         
                        </div>
                        </form>
                     </div>
                     <div class="col-lg-4">
                         <form action="" method="">
                        <div class="feature-banner">
                         <div class="banner-text">
                             
                                      <div class="banner-image">
                                           <label>Choose Image</label><br>
                                    <img src="https://thetestingserver.com/egssservices/assets/images/warranty-policy.png" width="50%" class="img-fluid">
                                 </div>
                             <div class="form-filed mt-3">
                               <input type="file" class="form-control">
                             </div>
                                <div class="form-field">
                                 <label> Heading</label>
                                 <input type="text" class="form-control" placeholder="heading" name="" value="">
                             </div>
                              <div class="form-field mt-1">
                                 <label>Description</label>
                                  <textarea class="tinymce-editor">
                                    <p>Hello World!</p>
                                 </textarea>
                             </div>
                              <div class="form-field mt-1">
                                 <label>Button Link</label>
                                 <input type="url" class="form-control" placeholder="url"  name="" value="">
                             </div>
                             <button class="btn d-button mt-4" type="submit">Submit</button>
                             
                                
                         </div>
                         
                        </div>
                        </form>
                     </div>
                  </div>
                 
                </div>
              </div>
        </div>
      </div>
        <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                     <h5 class="card-title">More Stories To Explore</h5>
                   <div class="row">
                     <div class="col-lg-4">
                          <form action="" method="">
                        <div class="feature-banner">
                         <div class="banner-text">
                             
                                      <div class="banner-image">
                                           <label>Choose Image</label><br>
                                    <img src="https://thetestingserver.com/egssservices/assets/images/vip-service-old.png" class="img-fluid">
                                 </div>
                             <div class="form-filed mt-3">
                               <input type="file" class="form-control">
                             </div>
                                <div class="form-field">
                                 <label>Heading</label>
                                 <input type="text" class="form-control" placeholder="heading" name="" value="">
                             </div>
                             
                              <div class="form-field mt-1">
                                 <label>Button Link</label>
                                 <input type="url" class="form-control" placeholder="url"  name="" value="">
                             </div>
                             <button class="btn d-button mt-4" type="submit">Submit</button>
                             
                                
                         </div>
                         
                        </div>
                        </form>
                     </div>
                    <div class="col-lg-4">
                         <form action="" method="">
                        <div class="feature-banner">
                         <div class="banner-text">
                             
                                      <div class="banner-image">
                                           <label>Choose Image</label><br>
                                    <img src="https://thetestingserver.com/egssservices/assets/images/banner-0301.png" class="img-fluid">
                                 </div>
                             <div class="form-filed mt-3">
                               <input type="file" class="form-control">
                             </div>
                                <div class="form-field">
                                 <label> Heading</label>
                                 <input type="text" class="form-control" placeholder="heading" name="" value="">
                             </div>
                              
                              <div class="form-field mt-1">
                                 <label>Button Link</label>
                                 <input type="url" class="form-control" placeholder="url"  name="" value="">
                             </div>
                             <button class="btn d-button mt-4" type="submit">Submit</button>
                             
                                
                         </div>
                         
                        </div>
                        </form>
                     </div>
                     <div class="col-lg-4">
                         <form action="" method="">
                        <div class="feature-banner">
                         <div class="banner-text">
                             
                                      <div class="banner-image">
                                           <label>Choose Image</label><br>
                                    <img src="https://thetestingserver.com/egssservices/assets/images/1-0309.png" class="img-fluid">
                                 </div>
                             <div class="form-filed mt-3">
                               <input type="file" class="form-control">
                             </div>
                                <div class="form-field">
                                 <label> Heading</label>
                                 <input type="text" class="form-control" placeholder="heading" name="" value="">
                             </div>
                             
                              <div class="form-field mt-1">
                                 <label>Button Link</label>
                                 <input type="url" class="form-control" placeholder="url"  name="" value="">
                             </div>
                             <button class="btn d-button mt-4" type="submit">Submit</button>
                             
                                
                         </div>
                         
                        </div>
                        </form>
                     </div>
                          <div class="col-lg-4 mt-3">
                         <form action="" method="">
                        <div class="feature-banner">
                         <div class="banner-text">
                             
                                      <div class="banner-image">
                                           <label>Choose Image</label><br>
                                    <img src="https://thetestingserver.com/egssservices/assets/images/pc-manager-0310.png" class="img-fluid">
                                 </div>
                             <div class="form-filed mt-3">
                               <input type="file" class="form-control">
                             </div>
                                <div class="form-field">
                                 <label> Heading</label>
                                 <input type="text" class="form-control" placeholder="heading" name="" value="">
                             </div>
                             
                              <div class="form-field mt-1">
                                 <label>Button Link</label>
                                 <input type="url" class="form-control" placeholder="url"  name="" value="">
                             </div>
                             <button class="btn d-button mt-4" type="submit">Submit</button>
                             
                                
                         </div>
                         
                        </div>
                        </form>
                     </div>
                  </div>
                 
                </div>
              </div>
        </div>
      </div>
      
      
      <!--<div class="row mt-5">-->
      <!--    <div class="col-12">-->
      <!--                  <div class="card">-->
      <!--                      <div id="Gallery-Body" class="card-body">-->
      <!--                          <div id="uploadedImages1">-->
      <!--                              <h4 class="card-title">Brand Images</h4>-->
      <!--                              <div class="single-table">-->
      <!--                                  <input type="file" class="form-control mb-3" id="file" name="file" multiple="">-->
      <!--                                  <form action="##"  method="POST">-->
      <!--                                          <div class="row">-->
      <!--                                              <div class="col-md-2 mt-3">-->
      <!--                                                  <input class="d-none form-check-input"  type="checkbox" name="gallery" value="">-->
      <!--                                                <div class="brand-img">-->
      <!--                                                  <img src="https://thetestingserver.com/eglobal_support/images/webimg/topbar-brands/microsoft.png" alt="" class="img-fluid w-100">-->
      <!--                                                 </div>-->
      <!--                                              </div>-->
      <!--                                              <div class="col-md-2 mt-3">-->
      <!--                                                  <input class="d-none form-check-input"  type="checkbox" name="gallery" value="">-->
      <!--                                                <div class="brand-img">-->
      <!--                                                  <img src="https://thetestingserver.com/eglobal_support/images/webimg/topbar-brands/dell.png" alt="" class="img-fluid w-100">-->
      <!--                                                 </div>-->
      <!--                                              </div>-->
      <!--                                              <div class="col-md-2 mt-3">-->
      <!--                                                  <input class="d-none form-check-input"  type="checkbox" name="gallery" value="">-->
      <!--                                                <div class="brand-img">-->
      <!--                                                  <img src="https://thetestingserver.com/eglobal_support/images/webimg/topbar-brands/apple.png" alt="" class="img-fluid w-100">-->
      <!--                                                 </div>-->
      <!--                                              </div>-->
      <!--                                              <div class="col-md-2 mt-3">-->
      <!--                                                  <input class="d-none form-check-input"  type="checkbox" name="gallery" value="">-->
      <!--                                                <div class="brand-img">-->
      <!--                                                  <img src="https://thetestingserver.com/eglobal_support/images/webimg/topbar-brands/acer.png" alt="" class="img-fluid w-100">-->
      <!--                                                 </div>-->
      <!--                                              </div><div class="col-md-2 mt-3">-->
      <!--                                                  <input class="d-none form-check-input"  type="checkbox" name="gallery" value="">-->
      <!--                                                <div class="brand-img">-->
      <!--                                                  <img src="https://thetestingserver.com/eglobal_support/images/webimg/topbar-brands/lenovo.png" alt="" class="img-fluid w-100">-->
      <!--                                                 </div>-->
      <!--                                              </div><div class="col-md-2 mt-3">-->
      <!--                                                  <input class="d-none form-check-input"  type="checkbox" name="gallery" value="">-->
      <!--                                                <div class="brand-img">-->
      <!--                                                  <img src="https://thetestingserver.com/eglobal_support/images/webimg/topbar-brands/toshiba.png" alt="" class="img-fluid w-100">-->
      <!--                                                 </div>-->
      <!--                                              </div>-->
      <!--                                              <div class="col-md-2 mt-3">-->
      <!--                                                  <input class="d-none form-check-input"  type="checkbox" name="gallery" value="">-->
      <!--                                                <div class="brand-img">-->
      <!--                                                  <img src="https://thetestingserver.com/eglobal_support/images/webimg/topbar-brands/asus.png" alt="" class="img-fluid w-100">-->
      <!--                                                 </div>-->
      <!--                                              </div>-->
                                                   
      <!--                                          </div>-->
                                            <!--<button class="btn btn-danger mt-4" type="submit" name="">Delete</button>-->
      <!--                                  </form>-->
      <!--                              </div>-->
      <!--                          </div>-->
      <!--                      </div>-->
      <!--                   </div>-->
      <!--              </div>-->


      <!--</div>-->
    </section>

  </main><!-- End #main -->

<?php include("footer.php"); ?>

</body>

</html>