 <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="index.php">
          <i class="fa fa-home"></i>
          <span>Home</span>
        </a>
      </li><!-- End Dashboard Nav -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="about.php">
          <i class="fa fa-user"></i>
          <span>About</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
       <a class="nav-link collapsed " data-bs-target="#category-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-menu-button-wide"></i><span>Services</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="category-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
            <li>
            <a href="category.php" class="active">
              <i class="bi bi-circle"></i><span>Category</span>
            </a>
          </li>
          <li>
            <a href="brands.php">
              <i class="bi bi-circle"></i><span>Brand</span>
            </a>
          </li>
          <li>
            <a href="models.php">
              <i class="bi bi-circle"></i><span>Model</span>
            </a>
          </li>
          <li>
            <a href="issue.php">
              <i class="bi bi-circle"></i><span>Issue</span>
            </a>
          </li>
        </ul>
      </li><!-- End Dashboard Nav -->
     
      <li class="nav-item">
        <a class="nav-link collapsed" href="seo-page.php">
          <i class="bi bi-grid"></i>
          <span>SEO</span>
        </a>
      </li><!-- End Dashboard Nav -->
       <li class="nav-item">
        <a class="nav-link collapsed" href="setting.php">
          <i class="bi bi-grid"></i>
          <span>Setting</span>
        </a>
      </li><!-- End Dashboard Nav -->
       <li class="nav-item">
        <a class="nav-link collapsed" href="submission.php">
          <i class="bi bi-grid"></i>
          <span>About</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <!--<li class="nav-item">-->
      <!--  <a class="nav-link collapsed" href="index.php">-->
      <!--    <i class="bi bi-grid"></i>-->
      <!--    <span>Brand</span>-->
      <!--  </a>-->
      <!--</li>-->
      <!-- End Dashboard Nav -->

      <!--<li class="nav-item">-->
      <!--  <a class="nav-link collapsed" href="index.php">-->
      <!--    <i class="bi bi-grid"></i>-->
      <!--    <span>Models</span>-->
      <!--  </a>-->
      <!--</li>-->
      <!-- End Dashboard Nav -->

      <!--<li class="nav-item">-->
      <!--  <a class="nav-link collapsed" href="index.php">-->
      <!--    <i class="bi bi-grid"></i>-->
      <!--    <span>Issues</span>-->
      <!--  </a>-->
      <!--</li>-->
      <!-- End Dashboard Nav -->




      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-register.php">
          <i class="bi bi-card-list"></i>
          <span>Register</span>
        </a>
      </li><!-- End Register Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-login.php">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Login</span>
        </a>
      </li><!-- End Login Page Nav -->


    </ul>

  </aside><!-- End Sidebar-->